const fetch = require("node-fetch");
const API_KEY = "api-key";
const BASE_URL = "https://acp-dev.gather.gg/api";

const listMatches = async ({
  tournament = "abc",
  pair = "sint ea velit",
  page = 1,
  pageSize = 10,
}) => {
  const requestOptions = { headers: { Authorization: API_KEY } };
  // const result = await fetch(
  //   `${BASE_URL}/v1/matches/?tournament=${tournament}&pair=${pair}&page=${page}&page_size=${pageSize}`,
  //   requestOptions
  // )
  const result = await fetch(`${BASE_URL}/v1/matches`, requestOptions)
    .then((response) => response.json())
    .catch((e) => console.error(e));
  console.log(result.results[0]);
  return result;
};

const listTournaments = async ({
  start,
  search,
  ownerId,
  game,
  status,
  mechanism,
  paymentType,
  visibleForMe,
  relatedUser,
  ordering,
  page = 1,
  pageSize = 10,
}) => {
  const requestOptions = { headers: { Authorization: API_KEY } };
  // const result = await fetch(
  //   `${BASE_URL}/v1/tournaments/?start=${start}&search=${search}&owner_id=${ownerId}&game=${game}&status=${status}&mechanism=${mechanism}&payment_type=${paymentType}&visible_for_me=${visibleForMe}&related_user=${relatedUser}&ordering=${ordering}&page=${page}&page_size=${pageSize}`,
  //   requestOptions
  // )
  const result = await fetch(`${BASE_URL}/v1/tournaments`, requestOptions)
    .then((response) => response.json())
    .catch((e) => console.error(e));
  return result;
};

const listGames = async ({}) => {
  const requestOptions = { headers: { Authorization: API_KEY } };
  const result = await fetch(`${BASE_URL}/v1/games`, requestOptions)
    .then((response) => response.json())
    .catch((e) => console.error(e));
  return result;
};

const listHeadToHeads = async ({}) => {
  const requestOptions = { headers: { Authorization: API_KEY } };
  const result = await fetch(`${BASE_URL}/v1/head-to-heads`, requestOptions)
    .then((response) => response.json())
    .catch((e) => console.error(e));
  return result;
};

const listJoinRequests = async ({}) => {
  const requestOptions = { headers: { Authorization: API_KEY } };
  const result = await fetch(`${BASE_URL}/v1/join-requests`, requestOptions)
    .then((response) => response.json())
    .catch((e) => console.error(e));
  return result;
};

const listPairs = async ({}) => {
  const requestOptions = { headers: { Authorization: API_KEY } };
  const result = await fetch(`${BASE_URL}/v1/pairs`, requestOptions)
    .then((response) => response.json())
    .catch((e) => console.error(e));
  return result;
};

const listParticipants = async ({}) => {
  const requestOptions = { headers: { Authorization: API_KEY } };
  const result = await fetch(`${BASE_URL}/v1/participants`, requestOptions)
    .then((response) => response.json())
    .catch((e) => console.error(e));
  return result;
};

const listRounds = async ({}) => {
  const requestOptions = { headers: { Authorization: API_KEY } };
  const result = await fetch(`${BASE_URL}/v1/rounds`, requestOptions)
    .then((response) => response.json())
    .catch((e) => console.error(e));
  return result;
};

const listSponsors = async ({}) => {
  const requestOptions = { headers: { Authorization: API_KEY } };
  const result = await fetch(`${BASE_URL}/v1/sponsors`, requestOptions)
    .then((response) => response.json())
    .catch((e) => console.error(e));
  return result;
};

const listStreams = async ({}) => {
  const requestOptions = { headers: { Authorization: API_KEY } };
  const result = await fetch(`${BASE_URL}/v1/streams`, requestOptions)
    .then((response) => response.json())
    .catch((e) => console.error(e));
  return result;
};

const listTeams = async ({}) => {
  const requestOptions = { headers: { Authorization: API_KEY } };
  const result = await fetch(`${BASE_URL}/v1/teams`, requestOptions)
    .then((response) => response.json())
    .catch((e) => console.error(e));
  return result;
};

// Resolvers define the technique for fetching the types in the schema.
const resolvers = {
  Query: {
    listGames: () => listGames({}),
    listHeadToHeads: () => listHeadToHeads({}),
    listJoinRequests: () => listJoinRequests({}),
    listGatherMatches: () => listMatches({}),
    listPairs: () => listPairs({}),
    listParticipants: () => listParticipants({}),
    listRounds: () => listRounds({}),
    listSponsors: () => listSponsors({}),
    listStreams: () => listStreams({}),
    listTeams: () => listTeams({}),
    listGatherTournaments: () => listTournaments({}),
  },
};

module.exports = resolvers;
