const { gql } = require("apollo-server-lambda");

const typeDefs = gql`
  # Models
  type Dispute {
    id: ID
    match: GatherMatch
    text: String
    image: String
    author: User
  }
  type Game {
    id: ID
    name: String
    icon: String
    cover: String
    background: String
    default_tournament_cover: String
    default_tournament_background: String
    add_to_main_banner: Boolean
    points_calculation_scheme: String
    supported_mechanics: [String]
    optional_gamer_tags: [String]
    mandatory_gamer_tags: [String]
  }
  type HeadToHead {
    id: ID
    second: User
    invitation_message: String
    game: Game
    first: User
    status: String
    muted_from: String
    muted_until: String
    first_points: Int
    second_points: Int
    created: String
    modified: String
  }
  type JoinRequest {
    id: ID
    team: Team
    user_statuses: [UserStatus]
  }
  type UserStatus {
    user: User
    status: String
  }
  type GatherMatch {
    id: ID
    author: User
    tournament: Tournament
    can_submit_score: Boolean
    can_create_dispute: Boolean
    status: String
  }
  type Pair {
    id: ID
    number: Int
    first: User
    second: User
    winner: Int
    loser: Int
    first_win_count: Int
    second_win_count: Int
    round: Round
    pair_scores: [Pair]
    can_submit_score: String
    can_dispute: String
  }
  type Participant {
    id: ID
    tournament: Tournament
    users: [User]
    team: Team
    created: String
    swiss_points: Int
    # swiss_history: {}
  }
  type Round {
    id: ID
    category: String
    number: Int
    grand_final: Boolean
  }
  type Sponsor {
    id: ID
    name: String
    image: String
    url: String
  }
  type Stream {
    id: ID
    tournament: ID
    url: String
  }
  type Team {
    id: ID
    name: String
    about: String
    image: String
    cover_image: String
    language: String
    website_url: String
    discord: String
    invites_welcome: Boolean
    new_members_welcome: Boolean
    hashcode: ID
    owner: User
    members: [User]
    created: String
    saved: Boolean
    last_play_tournament: String
    last_play_date: String
  }
  type Tournament {
    id: ID
    owner: User
    name: String
    game: String
    customization: Customization
    mechanism: String
    visibility: String
    finish: String
    hashcode: ID
    match_count: Int
    start: String
    participation_needs_approval: Boolean
    participation_type: String
    max_participants: Int
    with_grand_final: Boolean
    team_size: Int
    participant_count: Int
    status: String
    created: String
    duration: Int
    grace_period_duration: Int
    scoring: Int
    payment_type: String
    entry_fee: String
    prize_pool: String
    prizes: [String]
    related_user_team: String
  }
  type Customization {
    id: ID
  }
  type User {
    id: ID
    username: String
    verified: Boolean
    about: String
    country: String
    city: String
    image: String
    discord_server: String
    activision_id: String
    battlenet_id: String
    discord_profile: String
    epic_games_id: String
    nintendo_profile: String
    origin_id: String
    playstation_profile: String
    riot_profile: String
    steam_profile: String
    twitch_profile: String
    xbox_gamertag: String
    fighter_id: String
    chesscom_profile: String
    twitch_url: String
    website_url: String
    date_joined: String
    game: String
    cover_image: String
  }

  # Pagination
  type DisputesPage {
    count: Int
    next: String
    previous: String
    results: [Dispute]
  }
  type GamesPage {
    count: Int
    next: String
    previous: String
    results: [Game]
  }
  type HeadToHeadsPage {
    count: Int
    next: String
    previous: String
    results: [HeadToHead]
  }
  type JoinRequestsPage {
    count: Int
    next: String
    previous: String
    results: [JoinRequest]
  }
  type MatchesPage {
    count: Int
    next: String
    previous: String
    results: [GatherMatch]
  }
  type PairsPage {
    count: Int
    next: String
    previous: String
    results: [Pair]
  }
  type ParticipantsPage {
    count: Int
    next: String
    previous: String
    results: [Participant]
  }
  type RoundsPage {
    count: Int
    next: String
    previous: String
    results: [Round]
  }
  type SponsorsPage {
    count: Int
    next: String
    previous: String
    results: [Sponsor]
  }
  type StreamsPage {
    count: Int
    next: String
    previous: String
    results: [Stream]
  }
  type TeamsPage {
    count: Int
    next: String
    previous: String
    results: [Team]
  }
  type TournamentsPage {
    count: Int
    next: String
    previous: String
    results: [Tournament]
  }

  # Operations
  type Query {
    listDisputes: DisputesPage
    listGames: GamesPage
    listHeadToHeads: HeadToHeadsPage
    listJoinRequests: JoinRequestsPage
    listGatherMatches: MatchesPage
    listPairs: PairsPage
    listParticipants: ParticipantsPage
    listRounds: RoundsPage
    listSponsors: SponsorsPage
    listStreams: StreamsPage
    listTeams: TeamsPage
    listGatherTournaments: TournamentsPage
  }
`;

module.exports = typeDefs;
